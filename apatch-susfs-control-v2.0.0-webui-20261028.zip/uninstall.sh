#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
# Keep the user's structured settings, language and original rules.sh.
exit 0

#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
MODDIR=${0%/*}
. "$MODDIR/common.sh"
"$SUSFS" show version > "$STATE/boot-rules.log" 2>&1 || exit 1
"$SUSFS_MANAGER" boot late >> "$STATE/boot-rules.log" 2>&1

<!-- SPDX-License-Identifier: GPL-2.0-only -->
# APatch SUSFS Control WebUI 2.0.0

A Japanese/English WebUI for the standalone `v2.3.0-ap1 / APatch-GKI` kernel.
It works with the existing 001–015 kernel series. No kernel update or reflash is needed.
This module does not grant root and contains no KPM, LKM, or BakaSU implementation.

## Install or update

Install the ZIP through APatch Manager. It retains the module ID `apatch_susfs_control`
and upgrades version 1.0.0 without uninstalling it first. Reboot, then open the module’s
WebUI from APatch. Use the 日本語 / English selector at the upper right.
The language preference is stored on the device and survives module updates.

Open the page inside APatch; a regular browser has no root command bridge.
The WebUI uses bundled files and system fonts, with no server, CDN, or remote resources.

## Save, apply, and reboot

- **Save settings** persists your draft. Saving does not modify the kernel.
- **Apply saved settings** runs operations that can be applied now.
- **Apply automatically at boot** controls future boot application. It does not clear
  rules already present in the kernel.
- Status distinguishes saved settings, execution records, errors, and changes requiring reboot.
  Execution records are not a complete read-back of all kernel rules.

Pending unsaved edits disable the Apply button. Reloading with a dirty draft asks whether
to discard the draft. Rule removals and changes that cannot be undone in the current kernel
are explicitly shown as awaiting reboot.

## Supported settings

| Setting | Behavior |
|---|---|
| Mount visibility | Toggle visibility for mounts identified by the kernel as SuSFS targets. |
| AVC log context | Toggle target-context spoofing; separate from SELinux policy spoofing. |
| uname | Override release/version, or apply OFF to restore the kernel’s original strings. Maximum 63 UTF-8 bytes per value. |
| bootconfig | Replace the entire displayed text, up to 8190 bytes. Clearing requires reboot. |
| Priority UID filter | Select package names, including a user-app picker. Clearing takes effect after reboot. |
| Paths | Register normally or re-flag with the kernel’s 5-second loop. New rules can apply now; changes/removals require reboot. |
| maps | Register real mapped files. New rules can apply now; changes/removals require reboot. |
| Open Redirect | Specify original/destination paths and a UID condition. Both paths must exist. Changes/removals require reboot. |
| Normal/Full clone kstat | Capture before mounts on the next boot, then update after mounts. |
| Static kstat | Specify 12 metadata fields. New rules can apply now; changes/removals require reboot. |

Normal/Full clone is never falsely marked as captured by a post-boot manual apply.
If the post-mount stage does not run, boot completion retries updates of already captured
metadata. Nanosecond fields accept 0–999999999. Large integers remain strings;
empty static values or `default` retain the original value.

The priority filter affects getpriority/setpriority. It is not a per-app switch for all SuSFS
features. UID scope and ownership exceptions remain those of the existing kernel port.

## Existing rules.sh

`/data/adb/apatch-susfs/rules.sh` is neither overwritten nor deleted.
When its toggle is enabled, it runs at boot completion after structured settings.
It receives `SUSFS`, `MODDIR`, and `STATE`. Its content is visible read-only in the WebUI.
It may override structured settings or register rules that are not in the WebUI list.
There is no automatic conversion of shell scripts into structured rules.
Version 2.0.0 applies the 4-second command timeout to this script as well.

## Backup and restore

Create backup writes a JSON file under the root-only state directory and displays it in the
WebUI. Copying the JSON is also supported. To restore, paste JSON, validate it, use it as the
draft, then save. Importing alone does not apply anything to the kernel.
Only this module’s schema 1 JSON is supported, not BakaSU backup formats or shell scripts.

Settings live in `config.json`, preferences in `prefs.json`, under `/data/adb/apatch-susfs`.
The directory uses mode 0700 and settings files use 0600. Limits are 32 KB per configuration,
64 rules per category, and 128 package names.

## Logs and disabling

The log page shows exit codes, output, and deferral reasons. Each command has a 4-second
timeout; each operation has a 22-second budget. Failed actions are not marked as applied.
Large outputs and long action lists are abbreviated. At most 12 reports are retained within
the log size limit. Boot reports also appear in `post-fs-data.json`, `post-mount.json`, and
`boot-rules.log`. The original `status.txt` is retained.

To stop automatic application, disable its toggle, save, and reboot. Disabling or uninstalling
the module also needs a reboot to clear kernel-resident state. Saved settings and rules.sh
are kept when uninstalling.

## Compatibility and validation

This release targets exactly `v2.3.0-ap1 / APatch-GKI`. Root grants remain managed by APatch.
The WebUI does not add kernel logging support, change compile-time symbol-hiding settings,
or restore BakaSU-specific SELinux shadow-policy features.

The controller is built for Android ARM64/API 26. Native controller, lifecycle, validation,
language switching, and DOM interaction tests use a mock kernel helper.
**Installation, visual layout, and operation of this WebUI release on the physical device
have not been verified.** Browser preview access was denied, so no browser rendering test
was performed. See verification.json. The kernel patches and previously tested low-level
control helper remain unchanged.

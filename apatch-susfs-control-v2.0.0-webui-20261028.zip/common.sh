#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
MODDIR=${0%/*}
SUSFS="$MODDIR/bin/susfs_apatch"
SUSFS_MANAGER="$MODDIR/bin/susfs_manager"
STATE=/data/adb/apatch-susfs
export SUSFS
umask 077
"$SUSFS_MANAGER" init >/dev/null 2>&1 || exit 1

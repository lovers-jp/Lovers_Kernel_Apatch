#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
MODDIR=${0%/*}
. "$MODDIR/common.sh"
"$SUSFS_MANAGER" boot post > "$STATE/post-mount.json" 2>&1

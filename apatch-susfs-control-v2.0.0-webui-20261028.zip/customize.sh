#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
[ "$APATCH" = true ] || abort 'Install this module using APatch.'
[ "$ARCH" = arm64 ] || abort 'ARM64 is required.'
set_perm "$MODPATH/bin/susfs_apatch" 0 0 0755
set_perm "$MODPATH/bin/susfs_manager" 0 0 0755
"$MODPATH/bin/susfs_manager" init >/dev/null 2>&1 || abort 'Cannot initialize the settings store. Existing settings were preserved.'
ui_print 'SuSFS WebUI: Japanese / English'
ui_print 'Open the module WebUI after reboot.'
ui_print 'Existing /data/adb/apatch-susfs/rules.sh is preserved.'

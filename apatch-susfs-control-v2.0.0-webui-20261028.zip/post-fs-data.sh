#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
MODDIR=${0%/*}
. "$MODDIR/common.sh"
"$SUSFS" show version > "$STATE/status.txt" 2>&1 || exit 1
"$SUSFS" show variant >> "$STATE/status.txt" 2>&1
"$SUSFS" show enabled_features >> "$STATE/status.txt" 2>&1
"$SUSFS_MANAGER" boot pre > "$STATE/post-fs-data.json" 2>&1

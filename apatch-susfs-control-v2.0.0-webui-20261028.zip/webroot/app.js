// SPDX-License-Identifier: GPL-2.0-only
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const clone = value => JSON.parse(JSON.stringify(value));
  const categories = ['paths', 'kstats', 'maps', 'redirects'];
  const statFields = ['ino','dev','nlink','size','atime','atime_nsec','mtime','mtime_nsec','ctime','ctime_nsec','blocks','blksize'];
  const sections = [['status','◈'],['basic','☷'],['paths','⌁'],['kstats','▤'],['maps','▧'],['redirects','⇄'],['storage','↓'],['logs','≡']];
  const defaultConfig = () => ({schema:1,revision:0,startup:true,legacy_enabled:true,basic:{mount_hiding:false,avc_spoofing:false,uname:{enabled:false,release:'default',version:'default'},bootconfig:{enabled:false,text:''},priority:{enabled:false,packages:[]}},paths:[],kstats:[],maps:[],redirects:[]});
  let locale = navigator.language.startsWith('ja') ? 'ja' : 'en';
  try { locale = localStorage.getItem('susfs-language') || locale; } catch (_) {}
  if (!['ja','en'].includes(locale)) locale = 'ja';
  let localeTouched = false, page = 'status', snapshot = null, saved = defaultConfig(), draft = clone(saved);
  let busy = false, logEntries = [], jsonText = '', validatedImport = null, importMessage = '', lastError = '';
  let editorCategory = null, editorId = null, packageNames = [], packageSelection = new Set(), feedbackTimer;
  let rpcQueue = Promise.resolve(), callbackSequence = 0;
  const hasBridge = () => typeof window.ksu !== 'undefined' && typeof window.ksu.exec === 'function';
  const t = (key, values = {}) => {
    let text = window.SUSFS_I18N[locale][key] || window.SUSFS_I18N.en[key] || key;
    return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? `{${name}}`));
  };
  function el(tag, text = null, attrs = {}) {
    const node = document.createElement(tag);
    if (text !== null) node.textContent = String(text);
    for (const [key, value] of Object.entries(attrs)) {
      if (key === 'class') node.className = value;
      else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
      else if (key === 'checked' || key === 'disabled') node[key] = !!value;
      else node.setAttribute(key, value);
    }
    return node;
  }
  const add = (parent, ...children) => { children.filter(Boolean).forEach(n => parent.append(n)); return parent; };
  const badge = (text, type = '') => el('span',text,{class:`badge ${type}`});
  const note = (text, type = '') => el('p',text,{class:`note ${type}`});
  function button(key, fn, type = 'secondary', root = false) {
    return el('button',t(key),{type:'button',class:`${type}${root?' needs-bridge':''}`,onclick:fn});
  }
  function card(title) { const n=el('section',null,{class:'card'}); if (title) n.append(el('h3',t(title))); return n; }
  function notify(message) {
    clearTimeout(feedbackTimer); $('feedback').textContent=message; $('feedback').hidden=false;
    feedbackTimer=setTimeout(() => { $('feedback').hidden=true; },8000);
  }
  function showError(error) {
    const code=error.code || 'invalid_config';
    const key=`error_${code}`;
    const label=window.SUSFS_I18N[locale][key] ? t(key) : t('error_prefix');
    lastError=`${label}\n${error.message || code}`;
    notify(label); console.error('SUSFS controller:',code,error.message);
    render();
  }
  function callBridge(request) {
    return new Promise((resolve,reject) => {
      if (!hasBridge()) { const error=new Error(t('offline')); error.code='bridge'; reject(error); return; }
      const bytes=new TextEncoder().encode(JSON.stringify(request));
      if (bytes.length>49152) { const error=new Error('Request exceeds 48 KB');error.code='config_too_large';reject(error);return; }
      let binary=''; bytes.forEach(c => { binary+=String.fromCharCode(c); });
      const encoded=btoa(binary), callback=`__susfs_response_${++callbackSequence}`;
      const timer=setTimeout(() => { delete window[callback];const error=new Error(t('timeout'));error.code='timeout';reject(error); },45000);
      window[callback]=(errno,stdout,stderr) => {
        clearTimeout(timer);delete window[callback];
        try {
          const result=JSON.parse(String(stdout).trim());
          if (!result.ok) { const error=new Error(result.error?.message || stderr || `exit ${errno}`); error.code=result.error?.code || 'bridge';reject(error); }
          else if (errno!==0) { const error=new Error(stderr || `exit ${errno}`);error.code='bridge';reject(error); }
          else resolve(result);
        } catch (cause) { const error=new Error(`${cause.message}\n${String(stderr).slice(0,300)}`);error.code='bridge';reject(error); }
      };
      try { window.ksu.exec(`'/data/adb/modules/apatch_susfs_control/bin/susfs_manager' request '${encoded}'`,'{}',callback); }
      catch (cause) { clearTimeout(timer);delete window[callback];const error=new Error(cause.message);error.code='bridge';reject(error); }
    });
  }
  function api(request) {
    const job=rpcQueue.then(() => callBridge(request));
    rpcQueue=job.catch(() => {});return job;
  }
  async function work(fn) {
    if (busy) return;
    busy=true;updateControls();
    try { await fn();lastError=''; }
    catch (error) { showError(error); }
    finally { busy=false;render(); }
  }
  const isDirty = () => JSON.stringify(saved)!==JSON.stringify(draft);
  const feature = key => (snapshot?.connection.features || '').split(/\s+/).includes(`CONFIG_KSU_SUSFS_${key}`);
  function updateControls() {
    $('save-state').textContent=t(busy?'busy':isDirty()?'unsaved':'saved');
    $('dirty-state').classList.toggle('dirty',isDirty());
    for (const node of document.querySelectorAll('button,input,textarea,select')) {
      if (node.id==='language') continue;
      if (node.dataset.fixedDisabled==='true') {node.disabled=true;continue;}
      if (busy) {if (!node.disabled) node.dataset.busyDisabled='true';node.disabled=true;}
      else if (node.dataset.busyDisabled==='true') {node.disabled=false;delete node.dataset.busyDisabled;}
    }
    if (!busy) {
      $('save').disabled=!hasBridge() || !isDirty();
      $('apply').disabled=!hasBridge() || isDirty() || !snapshot?.connection.compatible;
      $('refresh').disabled=!hasBridge();
      document.querySelectorAll('.needs-bridge').forEach(n => {n.disabled=!hasBridge();});
    }
  }
  function changed() {validatedImport=null;updateControls();}
  function localizeStatic() {
    document.documentElement.lang=locale;
    document.querySelectorAll('[data-i18n]').forEach(n => {n.textContent=t(n.dataset.i18n);});
    $('language').value=locale;
    $('refresh').title=t('refresh');$('refresh').setAttribute('aria-label',t('refresh'));
    $('navigation').setAttribute('aria-label',t('basic'));
    for (const id of ['editor-close','packages-close']) $(id).setAttribute('aria-label',t('close'));
    $('package-search').placeholder=t('search_packages');
  }
  function header(key, desc, right=null) {
    const n=el('div',null,{class:'page-heading'}),left=el('div');
    add(left,el('h2',t(key)),el('p',t(desc)));add(n,left,right);return n;
  }
  function detail(parent,key,value,mono=false) {
    parent.append(add(el('div',null,{class:'detail-row'}),el('span',t(key)),el('span',value,{class:mono?'mono':''})));
  }
  function metric(label,value,caption='') {
    const n=card();add(n,el('div',t(label),{class:'card-label'}),el('div',value,{class:'metric small'}));
    if (caption) n.append(el('div',caption,{class:'card-caption'}));return n;
  }
  function reportSummary(report) {
    const n=el('div');
    if (!report) {n.append(el('p',t('no_apply'),{class:'subtitle'}));return n;}
    const pending=report.deferred_count>0 || (report.pending_reboot||[]).length>0;
    add(n,badge(t(report.startup_skipped?'skipped':!report.success?'partial':pending?'deferred':'success'),!report.success?'bad':pending?'warn':'good'),
      el('p',`${t(`phase_${report.phase}`)} · ${formatTime(report.time)}`,{class:'subtitle'}),
      el('p',t('actions_count',{count:report.action_count??report.actions.length,failed:report.failed_count??0,deferred:report.deferred_count??0}),{class:'subtitle'}));
    return n;
  }
  function formatTime(time) {return time ? new Date(time*1000).toLocaleString(locale==='ja'?'ja-JP':'en-US') : '—';}
  function renderStatus(root) {
    const connected=!!snapshot?.connection.connected, compatible=!!snapshot?.connection.compatible;
    root.append(header('status','status_desc',badge(t(compatible?'connected':connected?'unsupported_kernel':'disconnected'),compatible?'good':connected?'warn':'bad')));
    add(root,add(el('div',null,{class:'cards-metrics'}),metric('version',snapshot?.connection.version||'—'),metric('variant',snapshot?.connection.variant||'—'),metric('revision',`${saved.revision} / ${snapshot?.runtime.last_apply?.revision??'—'}`,t('revision_caption'))));
    const pending=snapshot?.pending_reboot || [];
    if (pending.length) {
      const n=card('reboot_required');n.append(note(t('pending_note'),'warning'));
      for (const item of pending) n.append(el('p',`${categories.includes(item.category)?t(item.category):t('basic')} · ${item.path} · ${t(item.reason)}`,{class:'rule-detail'}));
      root.append(n);
    }
    const features=card('features'),chips=el('div',null,{class:'chips'});
    const labels=[['SUS_PATH','paths'],['SUS_MOUNT','mount_hiding'],['SUS_KSTAT','kstats'],['SUS_MAP','maps'],['SPOOF_UNAME','uname'],['SPOOF_CMDLINE_OR_BOOTCONFIG','bootconfig'],['OPEN_REDIRECT','redirects'],['HIDE_KSU_SUSFS_SYMBOLS','symbol_hiding']];
    for (const [key,label] of labels) chips.append(el('span',`${feature(key)?'✓':'–'} ${t(label)}`,{class:`chip ${feature(key)?'enabled':''}`,title:`CONFIG_KSU_SUSFS_${key}`}));
    add(features,chips,el('p',t('features_note'),{class:'hint'}));root.append(features);
    const grid=el('div',null,{class:'grid'}),diagnostics=card('diagnostics'),latest=card('latest_apply');
    const d=snapshot?.diagnostics;
    detail(diagnostics,'uid',d?`${d.uid} / ${d.euid}`:'—');detail(diagnostics,'context',d?.context||'—',true);detail(diagnostics,'module_version',d?.module_version||'2.0.0');detail(diagnostics,'kernel',d?.release||'—',true);
    latest.append(reportSummary(snapshot?.runtime.last_apply));add(grid,diagnostics,latest);root.append(grid);
    root.append(note(t('tracking_note')));
    if (lastError) root.append(note(lastError,'error'));
    if (snapshot?.legacy_rules) {const n=card();const details=el('details');add(details,el('summary',t('legacy_view')),el('pre',snapshot.legacy_rules));n.append(details);root.append(n);}
  }
  function toggle(parent,key,value,onChange,hint,disabled=false) {
    const label=el('label',null,{class:'switch-row'}),text=el('span');
    add(text,el('strong',t(key)),hint?el('span',t(hint),{class:'hint'}):null);
    const input=el('input',null,{type:'checkbox',checked:value,'aria-label':t(key)});
    if (disabled) {input.disabled=true;input.dataset.fixedDisabled='true';}
    input.addEventListener('change',() => {onChange(input.checked);changed();});add(label,text,input);parent.append(label);return input;
  }
  function field(parent,key,value,onChange,options={}) {
    const label=el('label',null,{class:`field ${options.disabled?'disabled':''}`});
    label.append(el('span',t(key)));
    const input=el(options.multiline?'textarea':'input',null,{...(options.multiline?{}:{type:options.type||'text'}),'aria-label':t(key),...(options.mono?{class:'mono'}:{})});
    input.value=value;
    if (options.placeholder) input.placeholder=options.placeholder;
    if (options.disabled) {input.disabled=true;input.dataset.fixedDisabled='true';}
    input.addEventListener('input',() => {onChange(input.value);changed();});label.append(input);parent.append(label);return input;
  }
  function renderBasic(root) {
    root.append(header('basic','basic_desc'));
    const general=card('toggles');
    toggle(general,'startup',draft.startup,v=>{draft.startup=v;},'startup_hint');
    toggle(general,'legacy',draft.legacy_enabled,v=>{draft.legacy_enabled=v;},'legacy_hint');
    toggle(general,'mount_hiding',draft.basic.mount_hiding,v=>{draft.basic.mount_hiding=v;},'mount_hint',snapshot&&!feature('SUS_MOUNT'));
    toggle(general,'avc',draft.basic.avc_spoofing,v=>{draft.basic.avc_spoofing=v;},'avc_hint');root.append(general);
    const uname=card('uname');toggle(uname,'uname_enabled',draft.basic.uname.enabled,v=>{draft.basic.uname.enabled=v;},'uname_hint');
    const ug=el('div',null,{class:'field-grid'});field(ug,'release',draft.basic.uname.release,v=>{draft.basic.uname.release=v;},{mono:true});field(ug,'build_version',draft.basic.uname.version,v=>{draft.basic.uname.version=v;},{mono:true});uname.append(ug);root.append(uname);
    const boot=card('bootconfig');toggle(boot,'bootconfig_enabled',draft.basic.bootconfig.enabled,v=>{draft.basic.bootconfig.enabled=v;},'bootconfig_hint');field(boot,'bootconfig_text',draft.basic.bootconfig.text,v=>{draft.basic.bootconfig.text=v;},{multiline:true,mono:true});root.append(boot);
    const priority=card('priority');toggle(priority,'priority_enabled',draft.basic.priority.enabled,v=>{draft.basic.priority.enabled=v;},'priority_hint');
    field(priority,'packages',draft.basic.priority.packages.join('\n'),v=>{draft.basic.priority.packages=[...new Set(v.split(/[\s,]+/).filter(Boolean))];},{multiline:true,mono:true});
    priority.append(add(el('div',null,{class:'button-row'}),button('pick_packages',openPackages,'secondary',true)));root.append(priority);
    root.append(note(t('logging_note')));
  }
  function cleanRule(rule) {const item=clone(rule);delete item.id;delete item.enabled;return item;}
  function ruleState(category,rule) {
    const clean=cleanRule(rule),have=snapshot?.runtime.applied[category] || [];
    const target=rule.target || rule.path;
    const matching=have.find(item=>(item.target||item.path)===target);
    const sameSaved=saved[category].some(item=>JSON.stringify(item)===JSON.stringify(rule));
    if (!sameSaved) return ['draft_rule','warn'];
    if (matching && (!rule.enabled || JSON.stringify(matching)!==JSON.stringify(clean))) return ['changed_pending','warn'];
    if (!rule.enabled) return ['disabled',''];
    if (matching) return ['applied_record','good'];
    if (category==='kstats' && rule.mode!=='static') return ['capture_pending','warn'];
    return ['not_applied',''];
  }
  function renderRules(root,category) {
    root.append(header(category,'rules_desc',button('add_rule',()=>openEditor(category),'primary')));
    const hints={paths:'path_note',kstats:'kstat_note',maps:'map_note',redirects:'redirect_note'};
    root.append(note(t(hints[category])));
    const list=card();list.dataset.ruleList=category;
    if (!draft[category].length) {add(list,add(el('div',null,{class:'empty'}),el('div','+',{class:'empty-mark'}),el('h3',t('empty_rules')),el('p',t('empty_rules_hint'))));}
    for (const rule of draft[category]) {
      const row=el('article',null,{class:'rule','data-rule-id':rule.id}),heading=el('div',null,{class:'rule-heading'}),info=el('div');
      info.append(el('p',rule.target||rule.path,{class:'rule-path mono'}));
      if (category==='paths' && rule.loop) info.append(el('p',t('loop'),{class:'rule-detail'}));
      if (category==='redirects') info.append(el('p',`→ ${rule.destination}\n${t(`scheme_${rule.scheme}`)}`,{class:'rule-detail mono'}));
      if (category==='kstats') info.append(el('p',t(`mode_${rule.mode}`),{class:'rule-detail'}));
      const actions=el('div',null,{class:'rule-actions'});
      add(actions,button('edit',()=>openEditor(category,rule),'secondary'),button('remove',()=>{draft[category]=draft[category].filter(item=>item.id!==rule.id);changed();render();},'danger'));
      add(heading,info,actions);row.append(heading);
      const [key,type]=ruleState(category,rule);row.append(badge(t(key),type));list.append(row);
    }
    root.append(list);
  }
  function openEditor(category,rule=null) {
    editorCategory=category;editorId=rule?.id||null;
    const item=rule||{id:`r_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,10)}`,enabled:true,path:'',loop:false,mode:'normal',values:{},target:'',destination:'',scheme:3};
    drawEditor(item);if (!$('editor').open) $('editor').showModal();
  }
  function drawEditor(item) {
    $('editor-title').textContent=`${t(editorId?'edit_rule':'add_rule')} · ${t(editorCategory)}`;
    const root=$('editor-fields');root.replaceChildren();
    const formState=clone(item);root._rule=formState;
    toggle(root,'enabled',item.enabled,v=>{formState.enabled=v;},null);
    if (editorCategory!=='redirects') field(root,'path',item.path||'',v=>{formState.path=v;},{mono:true,placeholder:'/data/…'});
    if (editorCategory==='paths') toggle(root,'loop',item.loop||false,v=>{formState.loop=v;},'loop_hint');
    if (editorCategory==='redirects') {
      field(root,'target',item.target||'',v=>{formState.target=v;},{mono:true});field(root,'destination',item.destination||'',v=>{formState.destination=v;},{mono:true});
      const label=el('label',null,{class:'field'}),select=el('select',null,{'aria-label':t('scheme')});label.append(el('span',t('scheme')));
      for (let i=0;i<5;i++) select.append(el('option',t(`scheme_${i}`),{value:i}));select.value=String(item.scheme??3);
      select.addEventListener('change',()=>{formState.scheme=Number(select.value);});add(label,select);root.append(label);
    }
    if (editorCategory==='kstats') {
      const label=el('label',null,{class:'field'}),select=el('select',null,{'aria-label':t('mode')});label.append(el('span',t('mode')));
      for (const mode of ['normal','full_clone','static']) select.append(el('option',t(`mode_${mode}`),{value:mode}));select.value=item.mode||'normal';
      add(label,select);root.append(label);
      const values=el('div',null,{class:'field-grid stat-fields'});formState.values=formState.values||{};
      for (const key of statFields) field(values,`stat_${key}`,item.values?.[key]==='default'?'':item.values?.[key]||'',v=>{formState.values[key]=v.trim()||'default';},{placeholder:'default'});
      const hint=note(t('static_hint'));add(root,values,hint);
      const toggleValues=()=>{formState.mode=select.value;values.hidden=hint.hidden=select.value!=='static';};select.addEventListener('change',toggleValues);toggleValues();
    }
  }
  async function submitRule(event) {
    event.preventDefault();
    const raw=$('editor-fields')._rule;
    let item={id:raw.id,enabled:raw.enabled};
    if (editorCategory==='redirects') Object.assign(item,{target:raw.target.trim(),destination:raw.destination.trim(),scheme:raw.scheme});
    else item.path=raw.path.trim();
    if (editorCategory==='paths') item.loop=!!raw.loop;
    if (editorCategory==='kstats') Object.assign(item,{mode:raw.mode||'normal',values:Object.fromEntries(statFields.map(k=>[k,raw.values?.[k]?.trim()||'default']))});
    const next=clone(draft),index=next[editorCategory].findIndex(r=>r.id===editorId);
    if (index>=0) next[editorCategory][index]=item;else next[editorCategory].push(item);
    await work(async()=>{
      const result=await api({op:'validate',config:next});draft=result.config;
      $('editor').close();changed();
    });
  }
  async function openPackages() {
    await work(async()=>{
      const result=await api({op:'packages'});packageNames=result.packages;packageSelection=new Set(draft.basic.priority.packages);
      $('package-search').value='';renderPackages();$('package-picker').showModal();
    });
  }
  function renderPackages() {
    const root=$('package-list');root.replaceChildren();const search=$('package-search').value.toLowerCase();
    const names=Array.from(new Set([...packageNames,...packageSelection])).sort().filter(name=>name.toLowerCase().includes(search));
    if (!names.length) root.append(el('p',t('no_packages'),{class:'subtitle'}));
    for (const name of names) {
      const label=el('label'),input=el('input',null,{type:'checkbox',checked:packageSelection.has(name)});
      input.addEventListener('change',()=>{if(input.checked)packageSelection.add(name);else packageSelection.delete(name);});add(label,input,el('span',name));root.append(label);
    }
  }
  function renderStorage(root) {
    root.append(header('storage','storage_desc'));
    const backup=card('backup');add(backup,el('p',t('backup_hint'),{class:'subtitle'}),button('backup',()=>work(async()=>{
      const result=await api({op:'backup'});jsonText=JSON.stringify(result.config,null,2);validatedImport=null;importMessage='';notify(t('backup_created',{path:result.path}));
    }),'primary',true));root.append(backup);
    const restore=card('json_data');field(restore,'json_data',jsonText,v=>{jsonText=v;validatedImport=null;importMessage='';if($('import-use')){$('import-use').disabled=true;$('import-use').dataset.fixedDisabled='true';}if($('import-status'))$('import-status').textContent='';},{multiline:true,mono:true});
    const row=el('div',null,{class:'button-row'});
    add(row,button('copy',copyJSON),button('import_validate',()=>work(async()=>{
      let config;try{config=JSON.parse(jsonText);}catch(_){const error=new Error('Invalid JSON');error.code='invalid_json';throw error;}
      const result=await api({op:'validate',config});validatedImport=result.config;
      importMessage=t('import_valid',Object.fromEntries(categories.map(k=>[k,validatedImport[k].length])));
    }),'secondary',true));
    const use=button('import_use',()=>{if(!validatedImport)return;draft=clone(validatedImport);draft.revision=saved.revision;validatedImport=null;changed();notify(t('imported'));render();},'primary');
    use.id='import-use';
    if(!validatedImport){use.disabled=true;use.dataset.fixedDisabled='true';}row.append(use);
    add(restore,row,el('p',importMessage,{class:'inline-status',id:'import-status'}),note(t('import_hint')));root.append(restore);root.append(note(t('persisted_note')));
  }
  async function copyJSON() {
    try {
      let copied=false;
      if (navigator.clipboard?.writeText) {
        try {await navigator.clipboard.writeText(jsonText);copied=true;}catch(_){}
      }
      if (!copied) {
        const area=document.querySelector('#content textarea');area.focus();area.select();
        if(!document.execCommand('copy')){const error=new Error(t('error_copy_failed'));error.code='copy_failed';throw error;}
      }
      notify(t('copied'));
    } catch(error) {showError(error);}
  }
  async function loadLogs() {const result=await api({op:'logs'});logEntries=result.activity;}
  function renderLogs(root) {
    root.append(header('logs','logs_desc',button('log_refresh',()=>work(loadLogs),'secondary',true)));
    const list=card();
    if (!logEntries.length) list.append(el('p',t('empty_logs'),{class:'subtitle'}));
    for (const report of [...logEntries].reverse()) {
      const entry=el('article',null,{class:'log-entry'});entry.append(reportSummary(report));
      if(report.truncated)entry.append(note(t('truncated'),'warning'));
      const details=el('details');details.append(el('summary',t('log_details')));
      for (const action of report.actions) {
        let label=action.action;const colon=label.indexOf(':');
        if (colon>0&&categories.includes(label.slice(0,colon)))label=`${t(label.slice(0,colon))} · ${label.slice(colon+1)}`;
        else if(window.SUSFS_I18N[locale][label])label=t(label);
        const title=el('div',null,{class:'log-title'});
        add(title,el('span',label),badge(action.deferred?t(action.reason):`exit ${action.code}`,action.deferred?'warn':action.code===0?'good':'bad'));details.append(title);
        const text=[action.args?JSON.stringify(action.args):'',action.stdout||'',action.stderr||''].filter(Boolean).join('\n');if(text)details.append(el('pre',text));
      }
      entry.append(details);list.append(entry);
    }
    root.append(list);
  }
  function render() {
    const editorItem=$('editor').open ? clone($('editor-fields')._rule) : null;
    localizeStatic();
    const nav=$('navigation');nav.replaceChildren();
    for(const [key,icon] of sections) {
      const n=el('button',null,{type:'button',class:page===key?'active':'','aria-current':page===key?'page':'false','data-page':key,onclick:()=>{
        page=key;render();if(page==='logs'&&hasBridge())work(loadLogs);
      }});add(n,el('span',icon,{class:'nav-icon','aria-hidden':'true'}),el('span',t(key)));nav.append(n);
    }
    const root=$('content');root.replaceChildren();
    if(!hasBridge())root.append(note(t('offline'),'warning'));
    if(page==='status')renderStatus(root);
    else if(page==='basic')renderBasic(root);
    else if(categories.includes(page))renderRules(root,page);
    else if(page==='storage')renderStorage(root);
    else if(page==='logs')renderLogs(root);
    if(editorItem)drawEditor(editorItem);
    if($('package-picker').open)renderPackages();
    updateControls();
  }
  async function refresh(replace=true) {
    const result=await api({op:'status'});snapshot=result.data;
    if(replace){saved=clone(snapshot.config);draft=clone(saved);}
    if(!localeTouched&&['ja','en'].includes(snapshot.preferences?.locale))locale=snapshot.preferences.locale;
  }
  $('language').addEventListener('change',()=>{
    locale=$('language').value;localeTouched=true;try{localStorage.setItem('susfs-language',locale);}catch(_){}render();
    if(hasBridge())api({op:'preferences',locale}).catch(showError);
  });
  $('refresh').addEventListener('click',()=>{if(isDirty())$('discard-dialog').showModal();else work(()=>refresh());});
  $('discard-cancel').addEventListener('click',()=>$('discard-dialog').close());
  $('discard-confirm').addEventListener('click',()=>{$('discard-dialog').close();work(()=>refresh());});
  $('save').addEventListener('click',()=>work(async()=>{
    const result=await api({op:'save',config:draft,revision:saved.revision});saved=clone(result.config);draft=clone(saved);
    await refresh(false);notify(t('saved_notice'));
  }));
  $('apply').addEventListener('click',()=>work(async()=>{
    if(isDirty())throw new Error(t('save_before_apply'));
    const result=await api({op:'apply',revision:saved.revision});
    await refresh(false);await loadLogs();page='status';notify(t(result.report.success?'apply_notice':'partial_notice'));
  }));
  $('rule-form').addEventListener('submit',submitRule);
  for(const id of ['editor-close','editor-cancel'])$(id).addEventListener('click',()=>$('editor').close());
  $('packages-close').addEventListener('click',()=>$('package-picker').close());
  $('package-search').addEventListener('input',renderPackages);
  $('packages-done').addEventListener('click',()=>{draft.basic.priority.packages=[...packageSelection].sort();changed();$('package-picker').close();render();});
  render();
  if(hasBridge())work(()=>refresh());
})();
